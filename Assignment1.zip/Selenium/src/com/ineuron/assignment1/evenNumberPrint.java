package com.ineuron.assignment1;

public class evenNumberPrint {

	public static void main(String[] args) {
		System.out.println("The list of Even Numbers between 1-200 are:  ");

		for (int i = 1; i <=200; i++) {
			if (i % 2 == 0) {
				System.out.println(i);
			}

		}
	}

}
