package com.ineuron.assignment1;

public class breakExecution80 {

	public static void main(String[] args) {
		int number = 85;

		switch (number) {

		case 12:
			System.out.println("The number is 12");
			break;
		case 34:
			System.out.println("The number is 34");
			break;
		case 66:
			System.out.println("The number is 66");
			break;

		case 85:
			System.out.println("The number is 85");
			break;
		case 900:
			System.out.println("The number is 900");
			break;

		}

	}

}
