package com.ineuron.assignment1;

public class SwapNumbers {

	public static void main(String[] args) {

		int a = 10, b = 20, temp = 0;
		System.out.println("Before Swap");
		System.out.println("the value of a before swap is " + a);
		System.out.println("the value of b before swap is " + b);

		temp = a;
		a = b;
		b = temp;
		System.out.println("After Swap");
		System.out.println("the value of a after swap is " + a);
		System.out.println("the value of b after swap is " + b);

	}

}
