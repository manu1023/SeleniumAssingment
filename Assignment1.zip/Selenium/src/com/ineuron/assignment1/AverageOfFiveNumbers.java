package com.ineuron.assignment1;

public class AverageOfFiveNumbers {

	public static void main(String[] args) {
		int a = 10, c = 111, d = 8989, e = 7876;

		double b = 90.78;
		double avg = (a + b + c + d + e)/5;

		System.out.println("The average of Five numbers is(10,90.78,111,8989,7876): " + avg);
	}

}
