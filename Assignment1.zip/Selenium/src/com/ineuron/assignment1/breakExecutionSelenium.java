package com.ineuron.assignment1;

public class breakExecutionSelenium {

	public static void main(String[] args) {

		String name="Selenium";

		switch (name) {

		case "Java":
			System.out.println("Java");
			break;
		case "JavaScript":
			System.out.println("JavaScript");
			break;
		case "Selenium":
			System.out.println("Selenium");
			break;

		case "Python":
			System.out.println("Python");
			break;
		case "Mukesh":
			System.out.println("Mukesh");
			break;

		}

	}
}
