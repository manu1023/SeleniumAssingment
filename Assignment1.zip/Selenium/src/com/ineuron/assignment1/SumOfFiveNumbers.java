package com.ineuron.assignment1;

public class SumOfFiveNumbers {

	public static void main(String[] args) {
		int a = 10, c = 111, d = 8989, e = 7876;

		double b = 90.78;
		double x = a + b + c + d + e;

		System.out.println("The sum of Five numbers is(10,90.78,111,8989,7876): " + x);
	}

}
